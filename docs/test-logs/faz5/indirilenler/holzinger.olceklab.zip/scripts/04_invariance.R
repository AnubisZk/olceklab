## ÖlçekLab yeniden üretim betiği: M8 — Ölçme değişmezliği ve gizil ortalamalar
## Oluşturulma: 2026-11-03 00:40:07 UTC
## Veri özeti: sha256:21cf08c770d8ceec61548a575a29477025ea14ffc60fd6fd3359c12afdcd477f
## Bu betik bağımsızdır: R ve aşağıdaki paketler dışında hiçbir şey gerektirmez.
## Sonuçlar `sonuc` nesnesindedir.

stopifnot(isTRUE(l10n_info()[["UTF-8"]]))  # Türkçe sütun adları için UTF-8 yerel ayarı gerekir
olceklab_surumler <- c(lavaan = "0.7.2", semTools = "0.5.10", digest = "0.6.39", psych = "2.6.9")
for (p in names(olceklab_surumler)) {
  v <- as.character(utils::packageVersion(p))
  if (v != olceklab_surumler[[p]]) warning(sprintf("%s sürümü farklı: %s (ÖlçekLab: %s). Sonuçlar farklı olabilir.", p, v, olceklab_surumler[[p]]))
}
if (getRversion() != "4.4.3") warning("R sürümü farklı (ÖlçekLab: 4.4.3).")

## --- ÖlçekLab motorundan alınan veri okuma ve temizleme fonksiyonları (değiştirmeyin) ---
api_stop <- function (code, message_tr, status = 400L, detail = NULL) 
{
    cond <- structure(class = c("api_error", "error", "condition"), list(message = message_tr, call = NULL, 
        code = code, status = as.integer(status), detail = detail))
    stop(cond)
}

max_upload_bytes <- function () 
{
    as.numeric(Sys.getenv("MAX_UPLOAD_MB", "10")) * 1024^2
}

max_rows <- function () 
{
    as.integer(Sys.getenv("MAX_ROWS", "100000"))
}

parse_upload <- function (raw, filename) 
{
    if (!is.raw(raw) || length(raw) == 0L) 
        api_stop("empty_file", "Dosya boş.", 400L)
    if (length(raw) > max_upload_bytes()) {
        api_stop("file_too_large", sprintf("Dosya boyutu sınırı (%s MB) aşıldı.", format(max_upload_bytes()/1024^2)), 
            413L)
    }
    ext <- tolower(tools::file_ext(filename))
    df <- switch(ext, csv = , txt = , tsv = parse_delimited_bytes(raw), xlsx = , xls = parse_excel_bytes(raw, 
        ext), api_stop("unsupported_format", "Desteklenmeyen dosya biçimi. CSV ya da XLSX yükleyin.", 
        415L))
    validate_frame(df)
    list(data = df, hash = paste0("sha256:", digest::digest(raw, algo = "sha256", serialize = FALSE)), 
        filename = basename(filename), delimiter = attr(df, "delimiter"))
}

parse_delimited_bytes <- function (raw) 
{
    if (length(raw) >= 3L && identical(raw[1:3], as.raw(c(239, 187, 191)))) 
        raw <- raw[-(1:3)]
    if (any(raw == as.raw(0))) {
        api_stop("not_utf8", "Dosya UTF-8 metin dosyası değil. Dosyayı UTF-8 CSV olarak kaydedip yeniden yükleyin.", 
            422L)
    }
    txt <- rawToChar(raw)
    Encoding(txt) <- "UTF-8"
    if (!validUTF8(txt)) {
        api_stop("not_utf8", "Dosya UTF-8 kodlamasında değil. Dosyayı UTF-8 CSV olarak kaydedip yeniden yükleyin.", 
            422L)
    }
    lines <- strsplit(txt, "\r\n|\n|\r")[[1]]
    lines <- lines[nzchar(trimws(lines))]
    if (length(lines) < 2L) 
        api_stop("no_rows", "Dosyada başlık satırından sonra veri yok.", 422L)
    header <- gsub("\"[^\"]*\"", "", lines[1])
    counts <- c(`;` = lengths(regmatches(header, gregexpr(";", header, fixed = TRUE))), `,` = lengths(regmatches(header, 
        gregexpr(",", header, fixed = TRUE))), `\t` = lengths(regmatches(header, gregexpr("\t", header, 
        fixed = TRUE))))
    if (max(counts) == 0L) 
        api_stop("delimiter_not_found", "Sütun ayracı bulunamadı (; , ya da sekme).", 422L)
    sep <- names(counts)[which.max(counts)]
    con <- textConnection(lines, encoding = "UTF-8")
    on.exit(close(con), add = TRUE)
    df <- tryCatch(utils::read.table(con, sep = sep, header = TRUE, quote = "\"", colClasses = "character", 
        check.names = FALSE, na.strings = c("", "NA", "NaN"), strip.white = TRUE, comment.char = "", 
        encoding = "UTF-8", stringsAsFactors = FALSE), error = function(e) api_stop("parse_error", "Dosya okunamadı: satırlardaki sütun sayısı tutarsız olabilir.", 
        422L, conditionMessage(e)))
    names(df) <- trimws(names(df))
    df <- convert_columns(df, decimal_comma = sep != ",")
    attr(df, "delimiter") <- sep
    df
}

parse_excel_bytes <- function (raw, ext) 
{
    dir <- if (dir.exists("/dev/shm") && file.access("/dev/shm", 2L) == 0L) 
        "/dev/shm"
    else tempdir()
    path <- tempfile("olceklab-", tmpdir = dir, fileext = paste0(".", ext))
    on.exit(unlink(path, force = TRUE), add = TRUE)
    writeBin(raw, path)
    df <- tryCatch(readxl::read_excel(path, sheet = 1L, col_types = "text", .name_repair = "minimal"), 
        error = function(e) api_stop("parse_error", "Excel dosyası okunamadı.", 422L, conditionMessage(e)))
    df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
    names(df) <- trimws(names(df))
    df <- convert_columns(df, decimal_comma = TRUE)
    attr(df, "delimiter") <- NA_character_
    df
}

convert_columns <- function (df, decimal_comma) 
{
    for (j in seq_along(df)) {
        v <- trimws(as.character(df[[j]]))
        v[v %in% c("", "NA", "NaN")] <- NA_character_
        cand <- if (decimal_comma) 
            gsub(",", ".", v, fixed = TRUE)
        else v
        num <- suppressWarnings(as.numeric(cand))
        df[[j]] <- if (all(is.na(v) == is.na(num))) 
            num
        else v
    }
    df
}

validate_frame <- function (df) 
{
    nm <- names(df)
    if (ncol(df) == 0L || nrow(df) == 0L) 
        api_stop("no_rows", "Dosyada veri yok.", 422L)
    if (any(is.na(nm) | !nzchar(trimws(nm)))) 
        api_stop("blank_column_name", "Adı boş olan sütun var.", 422L)
    if (anyDuplicated(nm)) {
        api_stop("duplicate_column_name", sprintf("Aynı adı taşıyan sütunlar var: %s", paste(unique(nm[duplicated(nm)]), 
            collapse = ", ")), 422L)
    }
    if (nrow(df) > max_rows()) 
        api_stop("too_many_rows", sprintf("Satır sınırı (%d) aşıldı.", max_rows()), 413L)
    invisible(TRUE)
}

example_csv_hash <- function (df) 
{
    txt <- paste(utils::capture.output(utils::write.csv(df, row.names = FALSE)), collapse = "\n")
    paste0("sha256:", digest::digest(charToRaw(enc2utf8(txt)), algo = "sha256", serialize = FALSE))
}

load_example <- function (name) 
{
    if (identical(name, "holzinger")) {
        df <- lavaan::HolzingerSwineford1939
        df$school <- as.character(df$school)
        items <- paste0("x", 1:9)
        roles <- stats::setNames(rep("ignore", ncol(df)), names(df))
        roles[items] <- "item"
        roles["id"] <- "id"
        roles["school"] <- "group"
        cfg <- list(roles = as.list(roles), items = lapply(stats::setNames(items, items), function(i) list(reverse = FALSE, 
            subscale = c("visual", "textual", "speed")[(as.integer(sub("x", "", i)) - 1L)%/%3L + 1L])))
        source <- sprintf("lavaan %s: HolzingerSwineford1939", as.character(utils::packageVersion("lavaan")))
    }
    else if (identical(name, "bfi")) {
        df <- psych::bfi
        rownames(df) <- NULL
        items <- names(df)[1:25]
        reverse <- c("A1", "C4", "C5", "E1", "E2", "O2", "O5")
        roles <- stats::setNames(rep("ignore", ncol(df)), names(df))
        roles[items] <- "item"
        roles["gender"] <- "group"
        cfg <- list(roles = as.list(roles), items = lapply(stats::setNames(items, items), function(i) list(min = 1, 
            max = 6, reverse = i %in% reverse, subscale = substr(i, 1, 1))))
        source <- sprintf("psych %s: bfi", as.character(utils::packageVersion("psych")))
    }
    else {
        api_stop("example_not_found", "Örnek veri seti bulunamadı (holzinger ya da bfi).", 404L)
    }
    list(data = df, hash = example_csv_hash(df), filename = paste0(name, ".csv"), source = source, suggested_config = cfg)
}

clean_dataset <- function (data, config, rules = list()) 
{
    on <- function(key) if (is.null(rules[[key]])) 
        TRUE
    else isTRUE(rules[[key]])
    items <- config$items$name
    grp <- config$group
    x <- data
    n_raw <- nrow(x)
    keep <- rep(TRUE, n_raw)
    steps <- data.frame(step = character(), removed = integer(), remaining = integer(), stringsAsFactors = FALSE)
    add_step <- function(step, bad) {
        newly <- bad & keep
        keep <<- keep & !newly
        steps[nrow(steps) + 1L, ] <<- list(step, sum(newly), sum(keep))
    }
    item_missing <- vapply(items, function(i) mean(is.na(x[[i]])), numeric(1))
    if (!is.null(grp) && on("invalid_group")) {
        g <- x[[grp]]
        bad <- is.na(g)
        if (length(config$group_valid_values)) 
            bad <- bad | !(as.character(g) %in% config$group_valid_values)
        add_step("invalid_group", bad)
    }
    if (on("missing")) {
        add_step("missing", !stats::complete.cases(x[, items, drop = FALSE]))
    }
    bounded <- items[!is.na(config$items$min)]
    if (length(bounded) && on("out_of_range")) {
        bad <- rep(FALSE, n_raw)
        for (i in bounded) {
            v <- x[[i]]
            lo <- config$items$min[config$items$name == i]
            hi <- config$items$max[config$items$name == i]
            bad <- bad | (!is.na(v) & (v < lo | v > hi | v != round(v)))
        }
        add_step("out_of_range", bad)
    }
    if (on("straightline")) {
        m <- as.matrix(x[, items, drop = FALSE])
        bad <- apply(m, 1L, function(r) {
            r <- r[!is.na(r)]
            length(r) >= 2L && all(r == r[1])
        })
        add_step("straightline", bad)
    }
    out <- x[keep, c(items, grp), drop = FALSE]
    rownames(out) <- NULL
    reversed <- character()
    if (on("reverse")) {
        for (k in which(config$items$reverse)) {
            i <- config$items$name[k]
            out[[i]] <- config$items$min[k] + config$items$max[k] - out[[i]]
            reversed <- c(reversed, i)
        }
    }
    list(data = out, steps = steps, n_raw = n_raw, n_final = nrow(out), item_missing = item_missing, 
        reversed = reversed)
}

## --- 1. Veri ---
kaynak <- load_example("holzinger")
ham <- kaynak$data
stopifnot(identical(kaynak$hash, "sha256:21cf08c770d8ceec61548a575a29477025ea14ffc60fd6fd3359c12afdcd477f"))

## --- 2. Temizleme (ÖlçekLab ayarlarıyla) ---
config <- list(items = structure(list(name = c("x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9"), min = c(NA_real_, 
NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_), max = c(NA_real_, NA_real_, 
NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_, NA_real_), reverse = c(FALSE, FALSE, FALSE, 
FALSE, FALSE, FALSE, FALSE, FALSE, FALSE), subscale = c("visual", "visual", "visual", "textual", "textual", 
"textual", "speed", "speed", "speed")), row.names = c(NA, -9L), class = "data.frame"), group = "school", 
    group_valid_values = NULL, id_columns = structure("id", class = "AsIs"))
rules <- list(invalid_group = TRUE, out_of_range = TRUE, missing = TRUE, straightline = TRUE, reverse = TRUE)
temiz <- clean_dataset(ham, config, rules)$data

## --- 3. Analiz ---
items <- c("x1", "x2", "x3", "x4", "x5", "x6", "x7", "x8", "x9")
grup <- "school"
gruplar <- c("Pasteur", "Grant-White")
x <- temiz[, c(items, grup), drop = FALSE]
x <- x[!is.na(x[[grup]]), , drop = FALSE]
x[[grup]] <- as.character(x[[grup]])
x <- x[x[[grup]] %in% gruplar, , drop = FALSE]
options(mc.cores = 1)
RNGkind("Mersenne-Twister", "Inversion", "Rejection")
set.seed(20261030L)
yapisal_model <- "visual =~ x1 + x2 + x3\ntextual =~ x4 + x5 + x6\nspeed =~ x7 + x8 + x9"
fits <- list()
model <- yapisal_model
fits[["configural"]] <- lavaan::cfa(model, data = x, estimator = "ML", likelihood = "normal", std.lv = TRUE, group = "school", group.label = c("Pasteur", "Grant-White"))
model <- yapisal_model
fits[["metric"]] <- lavaan::cfa(model, data = x, estimator = "ML", likelihood = "normal", std.lv = TRUE, group = "school", group.label = c("Pasteur", "Grant-White"), group.equal = "loadings")
model <- yapisal_model
fits[["scalar"]] <- lavaan::cfa(model, data = x, estimator = "ML", likelihood = "normal", std.lv = TRUE, group = "school", group.label = c("Pasteur", "Grant-White"), group.equal = c("loadings", "intercepts"))
adimlar <- names(fits)
testler <- lapply(seq_along(adimlar)[-1], function(k) lavaan::lavTestLRT(fits[[k - 1]], fits[[k]])[2, c("Chisq diff", "Df diff", "Pr(>Chisq)")])
names(testler) <- adimlar[-1]
## Gizil ortalamalar: skaler modelle eşdeğer model; d := ile tanımlı (SH ve GA lavaan'dan)
model <- "visual =~ x1 + x2 + x3\ntextual =~ x4 + x5 + x6\nspeed =~ x7 + x8 + x9\nvisual ~ c(0, NA)*1 + c(olc_m_visual_g1, olc_m_visual_g2)*1\nvisual ~~ c(1, NA)*visual + c(olc_v_visual_g1, olc_v_visual_g2)*visual\nolc_d_visual_g2 := olc_m_visual_g2 / sqrt(((156 - 1) * 1 + (145 - 1) * olc_v_visual_g2) / (156 + 145 - 2))\ntextual ~ c(0, NA)*1 + c(olc_m_textual_g1, olc_m_textual_g2)*1\ntextual ~~ c(1, NA)*textual + c(olc_v_textual_g1, olc_v_textual_g2)*textual\nolc_d_textual_g2 := olc_m_textual_g2 / sqrt(((156 - 1) * 1 + (145 - 1) * olc_v_textual_g2) / (156 + 145 - 2))\nspeed ~ c(0, NA)*1 + c(olc_m_speed_g1, olc_m_speed_g2)*1\nspeed ~~ c(1, NA)*speed + c(olc_v_speed_g1, olc_v_speed_g2)*speed\nolc_d_speed_g2 := olc_m_speed_g2 / sqrt(((156 - 1) * 1 + (145 - 1) * olc_v_speed_g2) / (156 + 145 - 2))"
fit_gizil <- lavaan::cfa(model, data = x, estimator = "ML", likelihood = "normal", std.lv = TRUE, group = "school", group.label = c("Pasteur", "Grant-White"), group.equal = c("loadings", "intercepts"))
pe <- lavaan::parameterEstimates(fit_gizil)
gizil <- pe[pe$op == ":=" | (pe$op == "~1" & pe$lhs %in% lavaan::lavNames(fit_gizil, "lv")), ]
sonuc <- list(fit = lapply(fits, lavaan::fitMeasures), testler = testler, gizil = gizil)
print(sonuc)

