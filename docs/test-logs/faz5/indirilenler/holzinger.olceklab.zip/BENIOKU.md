# ÖlçekLab proje dosyası

- `manifest.json`: veri özeti (SHA-256), sütun rolleri ve temizleme isteği, analizlerin sırası ve özgün istek gövdeleri.
- `analyses/`: her analizin tam sonuç kaydı (17 anlamlı basamaklı sayılar ve R'nin biçimlediği metinler).
- `scripts/`: her analiz için bağımsız çalışan R betiği (veri yolu yer tutucuyla).
- `versions.json`: R ve paket sürümleri, BLAS/LAPACK, RNG türü.
- Veri dosyası eklenmedi. İçe aktarırken aynı dosyayı yükleyin; SHA-256 özeti denetlenir.

ÖlçekLab'de Başlangıç → Projeyi içe aktar ile açın: analizler yeniden çalıştırılır ve sonuçlar karşılaştırılır.

