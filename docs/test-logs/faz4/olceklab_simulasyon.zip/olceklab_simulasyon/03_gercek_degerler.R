## ÖlçekLab bağımsız simülasyon paketi — 03 gerçek değerler
## SİMÜLASYON — sentetik veri; ölçeğin geçerliğine kanıt değildir.
stopifnot(isTRUE(l10n_info()[["UTF-8"]]))
olceklab_surumler <- c(lavaan = "0.7.2", semTools = "0.5.10", psych = "2.6.9", MASS = "7.3.66", pbivnorm = "0.6.0", jsonlite = "2.0.0"
)
for (p in names(olceklab_surumler)) {
  v <- as.character(utils::packageVersion(p))
  if (v != olceklab_surumler[[p]]) warning(sprintf("%s sürümü farklı: %s (ÖlçekLab: %s). Sonuçlar farklı olabilir.", p, v, olceklab_surumler[[p]]))
}
if (getRversion() != "4.4.3") warning("R sürümü farklı (ÖlçekLab: 4.4.3).")

api_stop <- function (code, message_tr, status = 400L, detail = NULL) 
{
    cond <- structure(class = c("api_error", "error", "condition"), list(message = message_tr, call = NULL, 
        code = code, status = as.integer(status), detail = detail))
    stop(cond)
}

api_error_body <- function (code, message_tr, detail = NULL) 
{
    stopifnot(is.character(code), length(code) == 1L, nzchar(code))
    stopifnot(is.character(message_tr), length(message_tr) == 1L, nzchar(message_tr))
    list(error = list(code = code, message_tr = message_tr, detail = detail))
}

setting_choice <- function (x, name, choices, default = choices[1]) 
{
    v <- x[[name]]
    if (is.null(v)) 
        return(default)
    if (!is.character(v) || length(v) != 1L || !(v %in% choices)) {
        api_stop("invalid_setting", sprintf("'%s' ayarı şunlardan biri olmalıdır: %s.", name, paste(choices, 
            collapse = ", ")), 422L)
    }
    v
}

setting_number <- function (x, name, default, min = -Inf, max = Inf, integer = FALSE) 
{
    v <- x[[name]]
    if (is.null(v)) 
        return(default)
    if (!is.numeric(v) || length(v) != 1L || is.na(v) || v < min || v > max || (integer && v != round(v))) {
        api_stop("invalid_setting", sprintf("'%s' ayarı %s ile %s arasında %s olmalıdır.", name, 
            format(min), format(max), if (integer) 
                "bir tam sayı"
            else "bir sayı"), 422L)
    }
    if (integer) 
        as.integer(v)
    else as.numeric(v)
}

setting_flag <- function (x, name, default) 
{
    v <- x[[name]]
    if (is.null(v)) 
        return(default)
    if (!is.logical(v) || length(v) != 1L || is.na(v)) {
        api_stop("invalid_setting", sprintf("'%s' ayarı true ya da false olmalıdır.", name), 422L)
    }
    v
}

lavaan_name_ok <- function (x) 
grepl("^[\\p{L}.][\\p{L}\\p{N}._]*$", x, perl = TRUE) & !grepl("^\\.[0-9]", x)

sim_pop_error <- function (msg) 
api_stop("invalid_population", msg, 422L)

sim_as_list <- function (x) 
if (is.null(x)) list() else x

normalize_population <- function (spec) 
{
    if (!is.list(spec)) 
        sim_pop_error("Popülasyon tanımı bir nesne olmalıdır.")
    fs <- sim_as_list(spec$factors)
    if (!length(fs)) 
        sim_pop_error("Popülasyon modelinde en az bir faktör olmalıdır.")
    fnames <- vapply(fs, function(f) as.character(f$name)[1], "")
    if (anyDuplicated(fnames) || any(!lavaan_name_ok(fnames))) 
        sim_pop_error("Faktör adları benzersiz ve lavaan'da kullanılabilir olmalıdır.")
    items_by <- lapply(fs, function(f) as.character(unlist(f$items)))
    items <- unlist(items_by)
    if (anyDuplicated(items)) 
        sim_pop_error("Popülasyon modelinde her madde tek bir faktöre bağlı olmalıdır (basit yapı).")
    if (any(!lavaan_name_ok(items))) 
        sim_pop_error("Madde adları lavaan'da kullanılabilir olmalıdır.")
    if (any(lengths(items_by) < 2L)) 
        sim_pop_error("Her faktörde en az iki madde olmalıdır.")
    p <- length(items)
    k <- length(fnames)
    lam_in <- sim_as_list(spec$loadings)
    Lambda <- matrix(0, p, k, dimnames = list(items, fnames))
    for (j in seq_len(k)) for (it in items_by[[j]]) {
        v <- lam_in[[it]]
        if (is.null(v) || !is.numeric(v) || length(v) != 1L || is.na(v) || abs(v) >= 1 || v == 0) 
            sim_pop_error(sprintf("'%s' için standardize yük (0 dışında, mutlak değeri 1'den küçük) verilmelidir.", 
                it))
        Lambda[it, j] <- as.numeric(v)
    }
    Psi <- diag(k)
    dimnames(Psi) <- list(fnames, fnames)
    for (fc in sim_as_list(spec$factor_cor)) {
        a <- as.character(fc$a)
        b <- as.character(fc$b)
        r <- as.numeric(fc$r)
        if (!(a %in% fnames) || !(b %in% fnames) || a == b || length(r) != 1L || is.na(r) || abs(r) >= 
            1) 
            sim_pop_error("Faktör korelasyonları iki farklı faktör ve mutlak değeri 1'den küçük bir değer içermelidir.")
        Psi[a, b] <- Psi[b, a] <- r
    }
    if (min(eigen(Psi, symmetric = TRUE, only.values = TRUE)$values) <= 1e-08) 
        sim_pop_error("Faktör korelasyon matrisi pozitif tanımlı değil.")
    theta <- 1 - diag(Lambda %*% Psi %*% t(Lambda))
    if (any(theta <= 0)) 
        sim_pop_error(sprintf("Şu maddelerde artık varyans pozitif değil (yükler çok büyük): %s.", 
            paste(items[theta <= 0], collapse = ", ")))
    data_type <- if (is.null(spec$data_type)) 
        "ordinal"
    else as.character(spec$data_type)
    if (!(data_type %in% c("ordinal", "continuous"))) 
        sim_pop_error("data_type 'ordinal' ya da 'continuous' olmalıdır.")
    tau <- NULL
    props <- NULL
    if (data_type == "ordinal") {
        cp <- spec$category_props
        if (is.null(cp)) 
            sim_pop_error("Sıralı veri için kategori oranları (category_props) verilmelidir.")
        props <- if (is.list(cp) && !is.null(names(cp))) 
            lapply(items, function(it) as.numeric(unlist(cp[[it]])))
        else rep(list(as.numeric(unlist(cp))), p)
        names(props) <- items
        for (it in items) {
            pr <- props[[it]]
            if (length(pr) < 3L || any(is.na(pr)) || any(pr <= 0) || abs(sum(pr) - 1) > 1e-06) {
                sim_pop_error(sprintf("'%s' için kategori oranları en az üç pozitif değer olmalı ve toplamı 1 olmalıdır (ikili madde v1'de desteklenmez).", 
                  it))
            }
        }
        tau <- lapply(props, function(pr) stats::qnorm(cumsum(pr)[-length(pr)]))
    }
    gs <- sim_as_list(spec$groups)
    if (!length(gs)) 
        gs <- list(list(name = "Tek grup"))
    gnames <- vapply(gs, function(g) as.character(g$name)[1], "")
    if (anyDuplicated(gnames) || any(!nzchar(gnames))) 
        sim_pop_error("Grup adları benzersiz olmalıdır.")
    groups <- lapply(seq_along(gs), function(i) {
        g <- gs[[i]]
        alpha <- stats::setNames(rep(0, k), fnames)
        psi <- Psi
        if (i > 1L) {
            for (f in names(sim_as_list(g$latent_means))) {
                if (!(f %in% fnames)) 
                  sim_pop_error(sprintf("Bilinmeyen faktör: %s", f))
                alpha[[f]] <- as.numeric(g$latent_means[[f]])
            }
            for (f in names(sim_as_list(g$latent_var))) {
                if (!(f %in% fnames)) 
                  sim_pop_error(sprintf("Bilinmeyen faktör: %s", f))
                v <- as.numeric(g$latent_var[[f]])
                if (is.na(v) || v <= 0) 
                  sim_pop_error("Gizil varyans pozitif olmalıdır.")
                s <- sqrt(v)
                psi[f, ] <- psi[f, ] * s
                psi[, f] <- psi[, f] * s
            }
        }
        else if (length(g$latent_means) || length(g$latent_var)) {
            sim_pop_error("Referans grubun (ilk grup) gizil ortalaması 0, varyansı 1'dir; değiştirilemez.")
        }
        list(name = gnames[i], alpha = alpha, psi = psi)
    })
    dif <- list(list(name = "Değişmez (kontrol)", group = NULL, effects = list(), control = TRUE))
    for (d in sim_as_list(spec$dif)) {
        nm <- as.character(d$name)[1]
        if (is.na(nm) || !nzchar(nm)) 
            sim_pop_error("Her farklılık senaryosunun adı olmalıdır.")
        if (length(groups) < 2L) 
            sim_pop_error("Farklılık (DIF) senaryosu için en az iki grup gerekir.")
        g <- as.character(d$group)[1]
        if (!(g %in% gnames[-1])) 
            sim_pop_error(sprintf("'%s' senaryosundaki grup referans dışı bir grup olmalıdır.", 
                nm))
        eff <- lapply(sim_as_list(d$effects), function(e) {
            it <- as.character(e$item)
            ty <- as.character(e$type)
            sz <- as.numeric(e$size)
            if (!(it %in% items)) 
                sim_pop_error(sprintf("'%s' senaryosunda bilinmeyen madde: %s", nm, it))
            if (!(ty %in% c("threshold", "intercept", "loading"))) 
                sim_pop_error("Etki türü threshold, intercept ya da loading olmalıdır.")
            if (ty == "threshold" && data_type != "ordinal") 
                sim_pop_error("Eşik kayması yalnızca sıralı veride tanımlıdır; sürekli veride intercept kullanın.")
            if (ty == "intercept" && data_type == "ordinal") 
                sim_pop_error("Sıralı veride kesişim kayması yerine threshold kullanın.")
            if (length(sz) != 1L || is.na(sz)) 
                sim_pop_error("Etki büyüklüğü bir sayı olmalıdır.")
            list(item = it, type = ty, size = sz)
        })
        if (!length(eff)) 
            sim_pop_error(sprintf("'%s' senaryosunda en az bir etki olmalıdır.", nm))
        dif[[length(dif) + 1L]] <- list(name = nm, group = g, effects = eff, control = FALSE)
    }
    if (anyDuplicated(vapply(dif, `[[`, "", "name"))) 
        sim_pop_error("Senaryo adları benzersiz olmalıdır.")
    list(factors = stats::setNames(items_by, fnames), items = items, fnames = fnames, Lambda = Lambda, 
        Psi = Psi, theta = stats::setNames(theta, items), data_type = data_type, props = props, tau = tau, 
        groups = groups, gnames = gnames, dif = dif, spec = spec)
}

sim_model_syntax <- function (pop) 
{
    paste(vapply(pop$fnames, function(f) sprintf("%s =~ %s", f, paste(pop$factors[[f]], collapse = " + ")), 
        ""), collapse = "\n")
}

sim_group_sizes <- function (N, ratio) 
{
    if (length(ratio) == 1L) 
        return(as.integer(N))
    n <- as.integer(round(N * ratio[-length(ratio)]))
    c(n, as.integer(N) - sum(n))
}

sim_generate <- function (pop, N, ratio, scenario) 
{
    sizes <- sim_group_sizes(N, ratio)
    p <- length(pop$items)
    out <- vector("list", length(pop$groups))
    for (g in seq_along(pop$groups)) {
        G <- pop$groups[[g]]
        Lam <- pop$Lambda
        shift <- stats::setNames(rep(0, p), pop$items)
        if (!isTRUE(scenario$control) && identical(scenario$group, G$name)) {
            for (e in scenario$effects) {
                if (e$type == "loading") {
                  j <- which(Lam[e$item, ] != 0)
                  Lam[e$item, j] <- Lam[e$item, j] + e$size
                }
                else shift[[e$item]] <- shift[[e$item]] + e$size
            }
        }
        n <- sizes[g]
        eta <- MASS::mvrnorm(n, mu = G$alpha, Sigma = G$psi)
        if (n == 1L) 
            eta <- matrix(eta, nrow = 1L)
        eps <- matrix(stats::rnorm(n * p), n, p) %*% diag(sqrt(pop$theta), p)
        ystar <- eta %*% t(Lam) + eps
        colnames(ystar) <- pop$items
        if (pop$data_type == "ordinal") {
            x <- vapply(pop$items, function(it) findInterval(ystar[, it], pop$tau[[it]] + shift[[it]]) + 
                1L, integer(n))
            if (n == 1L) 
                x <- matrix(x, nrow = 1L, dimnames = list(NULL, pop$items))
            x <- as.data.frame(x)
        }
        else {
            x <- as.data.frame(sweep(ystar, 2, shift, `+`))
        }
        x$grp <- G$name
        out[[g]] <- x
    }
    d <- do.call(rbind, out)
    rownames(d) <- NULL
    d
}

sim_seed <- function (seed, cond, rep) 
as.integer(seed + 10000L * cond + rep)

sim_try_fit <- function (syntax, data, args) 
{
    w <- character()
    fit <- tryCatch(withCallingHandlers(suppressMessages(do.call(lavaan::cfa, c(list(model = syntax, 
        data = data), args))), warning = function(x) {
        w <<- c(w, conditionMessage(x))
        invokeRestart("muffleWarning")
    }), error = function(e) e)
    if (inherits(fit, "error")) 
        return(list(status = "other", message = conditionMessage(fit)))
    if (!isTRUE(lavaan::lavInspect(fit, "converged"))) 
        return(list(status = "nonconverged", message = paste(unique(w), collapse = " | ")))
    pc <- suppressWarnings(lavaan::lavInspect(fit, "post.check"))
    list(status = if (isTRUE(pc)) "ok" else "improper", fit = fit, message = paste(unique(w), collapse = " | "))
}

sim_fm <- function (fit, est) 
{
    sc <- est != "ML"
    k <- if (sc) 
        c(chisq = "chisq.scaled", df = "df.scaled", pvalue = "pvalue.scaled", cfi = "cfi.scaled", tli = "tli.scaled", 
            rmsea = "rmsea.scaled")
    else c(chisq = "chisq", df = "df", pvalue = "pvalue", cfi = "cfi", tli = "tli", rmsea = "rmsea")
    fm <- suppressWarnings(lavaan::fitMeasures(fit, c(unname(k), "srmr", "srmr_bentler_nomean")))
    out <- stats::setNames(as.numeric(fm[unname(k)]), names(k))
    c(out, srmr = as.numeric(fm[["srmr"]]), srmr_bn = if ("srmr_bentler_nomean" %in% names(fm)) as.numeric(fm[["srmr_bentler_nomean"]]) else NA_real_)
}

sim_empty_category <- function (pop, d) 
{
    if (pop$data_type != "ordinal") 
        return(FALSE)
    K <- vapply(pop$props, length, integer(1))
    any(vapply(split(d, d$grp), function(g) any(vapply(pop$items, function(it) length(unique(g[[it]])) < 
        K[[it]], logical(1))), logical(1)))
}

sim_cfa_args <- function (pop, est) 
{
    a <- list(estimator = est, std.lv = TRUE)
    if (est == "WLSMV") 
        a$ordered <- pop$items
    a
}

sim_analyse_cfa <- function (pop, d, est, analyses) 
{
    x <- d[d$grp == pop$gnames[1], pop$items, drop = FALSE]
    if (est == "WLSMV" && sim_empty_category(pop, d[d$grp == pop$gnames[1], , drop = FALSE])) 
        return(list(status = "empty_category"))
    ft <- sim_try_fit(sim_model_syntax(pop), x, sim_cfa_args(pop, est))
    out <- list(status = ft$status, message = ft$message)
    if (is.null(ft$fit)) 
        return(out)
    out$fit <- sim_fm(ft$fit, est)
    ss <- lavaan::standardizedSolution(ft$fit)
    keep <- ss$op == "=~" | (ss$op == "~~" & ss$lhs != ss$rhs & ss$lhs %in% pop$fnames) | ss$op == "|"
    ss <- ss[keep, ]
    out$params <- data.frame(name = ifelse(ss$op == "|", paste0(ss$lhs, "|", ss$rhs), paste0(ss$lhs, 
        ss$op, ss$rhs)), type = ifelse(ss$op == "=~", "loading", ifelse(ss$op == "~~", "factor_cor", 
        "threshold")), est = ss$est.std, se = ss$se, lower = ss$ci.lower, upper = ss$ci.upper, stringsAsFactors = FALSE)
    if (isTRUE(analyses$reliability)) {
        om <- tryCatch(suppressWarnings(semTools::compRelSEM(ft$fit, simplify = TRUE)), error = function(e) NULL)
        omv <- if (is.null(om)) 
            rep(NA_real_, length(pop$fnames))
        else {
            v <- as.numeric(unclass(om))
            if (is.null(names(om)) && length(v) == 1L) 
                v
            else as.numeric(om[pop$fnames])
        }
        al <- vapply(pop$fnames, function(f) suppressWarnings(psych::alpha(x[, pop$factors[[f]], drop = FALSE], 
            check.keys = FALSE, warnings = FALSE))$total$raw_alpha, numeric(1))
        out$reliability <- data.frame(factor = pop$fnames, alpha = unname(al), omega = omv, stringsAsFactors = FALSE)
    }
    out
}

sim_inv_steps <- function (est) 
{
    if (est == "WLSMV") 
        list(configural = character(0), metric = c("thresholds", "loadings"), scalar = c("thresholds", 
            "loadings", "intercepts"))
    else list(configural = character(0), metric = "loadings", scalar = c("loadings", "intercepts"))
}

sim_analyse_invariance <- function (pop, d, est, crit) 
{
    if (est == "WLSMV" && sim_empty_category(pop, d)) 
        return(list(status = "empty_category"))
    syn0 <- sim_model_syntax(pop)
    steps <- sim_inv_steps(est)
    fits <- list()
    rows <- list()
    for (st in names(steps)) {
        eq <- steps[[st]]
        if (est == "WLSMV") {
            syn <- tryCatch(as.character(suppressMessages(semTools::measEq.syntax(configural.model = syn0, 
                data = d, ordered = pop$items, parameterization = "theta", ID.fac = "std.lv", ID.cat = "Wu.Estabrook.2016", 
                group = "grp", group.label = pop$gnames, group.equal = if (length(eq)) eq else ""))), 
                error = function(e) e)
            if (inherits(syn, "error")) 
                return(list(status = "other", message = conditionMessage(syn), step = st))
            args <- list(estimator = "WLSMV", parameterization = "theta", ordered = pop$items, group = "grp", 
                group.label = pop$gnames)
        }
        else {
            syn <- syn0
            args <- list(estimator = est, std.lv = TRUE, group = "grp", group.label = pop$gnames)
            if (length(eq)) 
                args$group.equal <- eq
        }
        ft <- sim_try_fit(syn, d, args)
        if (ft$status != "ok") 
            return(list(status = ft$status, message = ft$message, step = st))
        fits[[st]] <- ft$fit
        rows[[st]] <- sim_fm(ft$fit, est)
    }
    method <- cfa_lrt_method(est)
    cmp <- lapply(2:length(fits), function(k) {
        lr <- tryCatch(suppressWarnings(if (method == "standard") 
            lavaan::lavTestLRT(fits[[k - 1L]], fits[[k]])
        else lavaan::lavTestLRT(fits[[k - 1L]], fits[[k]], method = method)), error = function(e) NULL)
        p <- if (is.null(lr)) 
            NA_real_
        else lr[2, "Pr(>Chisq)"]
        dchi <- if (is.null(lr)) 
            NA_real_
        else lr[2, "Chisq diff"]
        if (method == "satorra.bentler.2001" && isTRUE(dchi < 0)) {
            lr <- tryCatch(suppressWarnings(lavaan::lavTestLRT(fits[[k - 1L]], fits[[k]], method = "satorra.bentler.2010")), 
                error = function(e) NULL)
            p <- if (is.null(lr)) 
                NA_real_
            else lr[2, "Pr(>Chisq)"]
            dchi <- if (is.null(lr)) 
                NA_real_
            else lr[2, "Chisq diff"]
        }
        a <- rows[[k - 1L]]
        b <- rows[[k]]
        st <- names(fits)[k]
        srmr_lim <- if (st == "metric") 
            crit$srmr_load
        else crit$srmr_int
        data.frame(step = st, chisq_diff = dchi, p = p, delta_cfi = b[["cfi"]] - a[["cfi"]], delta_rmsea = b[["rmsea"]] - 
            a[["rmsea"]], delta_srmr = b[["srmr_bn"]] - a[["srmr_bn"]], reject_chisq = isTRUE(p < crit$alpha), 
            reject_cfi = isTRUE(b[["cfi"]] - a[["cfi"]] < crit$cfi), reject_rmsea = isTRUE(b[["rmsea"]] - 
                a[["rmsea"]] > crit$rmsea), reject_srmr = isTRUE(b[["srmr_bn"]] - a[["srmr_bn"]] > srmr_lim), 
            stringsAsFactors = FALSE)
    })
    pe <- lavaan::parameterEstimates(fits$scalar)
    lm <- pe[pe$op == "~1" & pe$lhs %in% pop$fnames & pe$group > 1L, ]
    list(status = "ok", steps = do.call(rbind, cmp), latent_means = data.frame(name = paste0(lm$lhs, 
        "~1@", pop$gnames[lm$group]), est = lm$est, se = lm$se, lower = lm$ci.lower, upper = lm$ci.upper, 
        stringsAsFactors = FALSE))
}

sim_pa_reference <- function (N, p, n_iter, quant) 
{
    ev <- vapply(seq_len(n_iter), function(i) eigen(stats::cor(matrix(stats::rnorm(N * p), N, p)), symmetric = TRUE, 
        only.values = TRUE)$values, numeric(p))
    apply(ev, 1, stats::quantile, quant, names = FALSE)
}

sim_analyse_pa <- function (pop, d, pa, ref) 
{
    x <- d[, pop$items, drop = FALSE]
    obs <- eigen(stats::cor(x), symmetric = TRUE, only.values = TRUE)$values
    if (is.null(ref)) {
        r <- tryCatch(quiet(psych::fa.parallel(x, fa = "pc", n.iter = pa$n_iter, sim = TRUE, quant = pa$quant, 
            plot = FALSE))$value, error = function(e) NULL)
        if (is.null(r)) 
            return(NA_integer_)
        return(as.integer(r$ncomp))
    }
    k <- count_leading(obs, ref)
    if (is.na(k)) 
        length(obs)
    else as.integer(k)
}

sim_replicate <- function (pop, cond, rep, seed, estimators, analyses, crit, pa_ref = NULL) 
{
    s <- sim_seed(seed, cond$index, rep)
    RNGkind("Mersenne-Twister", "Inversion", "Rejection")
    set.seed(s)
    d <- sim_generate(pop, cond$N, cond$ratio, pop$dif[[cond$scenario]])
    out <- list(cond = cond$index, rep = rep, seed = s, empty_category = sim_empty_category(pop, d), 
        est = list())
    if (isTRUE(analyses$pa$enabled)) 
        out$pa <- sim_analyse_pa(pop, d, analyses$pa, pa_ref)
    for (est in estimators) {
        r <- list()
        if (isTRUE(analyses$cfa)) 
            r$cfa <- sim_analyse_cfa(pop, d, est, analyses)
        if (isTRUE(analyses$invariance) && length(pop$groups) >= 2L) 
            r$invariance <- sim_analyse_invariance(pop, d, est, crit)
        out$est[[est]] <- r
    }
    out
}

cfa_lrt_method <- function (estimator) 
switch(estimator, ML = "standard", MLR = "satorra.bentler.2001", WLSMV = "satorra.2000")

cfa_estimators <- c("ML", "MLR", "WLSMV")

count_leading <- function (observed, reference) 
{
    which(!(observed > reference))[1] - 1L
}

quiet <- function (expr) 
{
    out <- NULL
    utils::capture.output(out <- collect_conditions(expr), file = nullfile())
    out
}

collect_conditions <- function (expr) 
{
    msgs <- character()
    value <- withCallingHandlers(suppressMessages(expr), warning = function(w) {
        msgs <<- c(msgs, conditionMessage(w))
        invokeRestart("muffleWarning")
    })
    list(value = value, warnings = unique(msgs))
}

online_limits <- function () 
{
    on <- tolower(Sys.getenv("ONLINE_LIMITS", "false")) %in% c("true", "1", "yes")
    list(enabled = on, max_total = as.integer(Sys.getenv("ONLINE_MAX_REPLICATIONS_X_CONDITIONS", "2000")), 
        max_workers = as.integer(Sys.getenv("ONLINE_MAX_WORKERS", "2")), timeout = as.numeric(Sys.getenv("ONLINE_JOB_TIMEOUT_SECONDS", 
            "3600")))
}

sim_spec_defaults <- list(reps = 1000L, seed = 20261030L, chunk_size = 250L)

normalize_sim_spec <- function (body) 
{
    if (!is.list(body)) 
        api_stop("invalid_simulation", "Simülasyon tanımı bir nesne olmalıdır.", 422L)
    pop <- normalize_population(body$population)
    cd <- if (is.list(body$conditions)) 
        body$conditions
    else list()
    Ns <- as.integer(unlist(cd$N))
    if (!length(Ns) || anyNA(Ns) || any(Ns < 30L) || anyDuplicated(Ns)) 
        api_stop("invalid_simulation", "N listesi en az 30 olan, birbirinden farklı tam sayılardan oluşmalıdır.", 
            422L)
    G <- length(pop$groups)
    ratios <- if (G == 1L) 
        list(1)
    else {
        rr <- cd$ratios
        if (is.null(rr) || !length(rr)) 
            list(rep(1/G, G))
        else lapply(rr, function(r) as.numeric(unlist(r)))
    }
    for (r in ratios) if (length(r) != G || any(is.na(r)) || any(r <= 0)) 
        api_stop("invalid_simulation", sprintf("Her grup oranı %d pozitif değerden oluşmalıdır (ör. 70/30 ya da ,7/,3).", 
            G), 422L)
    ratios <- lapply(ratios, function(r) r/sum(r))
    scen_names <- vapply(pop$dif, `[[`, "", "name")
    sc <- if (is.null(cd$scenarios)) 
        scen_names
    else as.character(unlist(cd$scenarios))
    if (!length(sc) || any(!(sc %in% scen_names))) 
        api_stop("invalid_simulation", "Bilinmeyen senaryo adı.", 422L)
    sc_idx <- match(sc, scen_names)
    est <- if (is.null(body$estimators)) 
        "ML"
    else unique(as.character(unlist(body$estimators)))
    if (!length(est) || any(!(est %in% cfa_estimators))) 
        api_stop("invalid_simulation", "Kestiriciler ML, MLR ya da WLSMV olmalıdır.", 422L)
    if ("WLSMV" %in% est && pop$data_type != "ordinal") 
        api_stop("invalid_simulation", "WLSMV yalnızca sıralı veri üretiminde seçilebilir.", 422L)
    reps <- setting_number(body, "reps", sim_spec_defaults$reps, 1, 10000, integer = TRUE)
    seed <- setting_number(body, "seed", sim_spec_defaults$seed, 1, .Machine$integer.max - 1e+08, integer = TRUE)
    chunk <- setting_number(body, "chunk_size", sim_spec_defaults$chunk_size, 1, 10000, integer = TRUE)
    an <- if (is.list(body$analyses)) 
        body$analyses
    else list()
    pa <- if (is.list(an$pa)) 
        an$pa
    else list()
    analyses <- list(cfa = setting_flag(an, "cfa", TRUE), invariance = setting_flag(an, "invariance", 
        G >= 2L) && G >= 2L, reliability = setting_flag(an, "reliability", TRUE), pa = list(enabled = setting_flag(pa, 
        "enabled", FALSE), n_iter = setting_number(pa, "n_iter", 100L, 10, 5000, integer = TRUE), quant = setting_number(pa, 
        "quant", 0.95, 0.5, 0.999), per_cell = setting_flag(pa, "per_cell", TRUE)))
    cr <- if (is.list(body$criteria)) 
        body$criteria
    else list()
    crit <- list(alpha = setting_number(cr, "alpha", 0.05, 1e-04, 0.5), cfi = setting_number(cr, "cfi", 
        -0.01, -1, 0), rmsea = setting_number(cr, "rmsea", 0.015, 0, 1), srmr_load = setting_number(cr, 
        "srmr_load", 0.03, 0, 1), srmr_int = setting_number(cr, "srmr_int", 0.01, 0, 1))
    rc <- if (is.list(body$recommend)) 
        body$recommend
    else list()
    cov <- if (is.null(rc$coverage)) 
        c(0.91, 0.98)
    else as.numeric(unlist(rc$coverage))
    rec <- list(admissible = setting_number(rc, "admissible", 0.95, 0, 1), param_bias = setting_number(rc, 
        "param_bias", 0.1, 0, 1), se_bias = setting_number(rc, "se_bias", 0.1, 0, 1), coverage = cov, 
        power = setting_number(rc, "power", 0.8, 0, 1), power_step = setting_choice(rc, "power_step", 
            c("auto", "scalar", "metric")), rel_cut = setting_number(rc, "rel_cut", 0.1, 0, 1))
    grid <- expand.grid(scenario = sc_idx, ratio = seq_along(ratios), N = Ns, KEEP.OUT.ATTRS = FALSE)[, 
        c("N", "ratio", "scenario")]
    grid$index <- seq_len(nrow(grid))
    lim <- online_limits()
    if (lim$enabled && reps * nrow(grid) > lim$max_total) {
        api_stop("online_limit", sprintf("Çevrim içi modda tekrar × koşul en fazla %d olabilir (istenen: %d). Bağımsız R paketini indirip kendi bilgisayarınızda çalıştırabilirsiniz.", 
            lim$max_total, reps * nrow(grid)), 422L)
    }
    list(pop = pop, Ns = Ns, ratios = ratios, scenarios = sc_idx, estimators = est, reps = reps, seed = seed, 
        chunk_size = chunk, analyses = analyses, criteria = crit, recommend = rec, grid = grid, body = body)
}

sim_chunks <- function (spec) 
{
    out <- list()
    for (ci in spec$grid$index) {
        starts <- seq(1L, spec$reps, by = spec$chunk_size)
        for (s in starts) out[[length(out) + 1L]] <- list(cond = ci, from = s, to = min(spec$reps, s + 
            spec$chunk_size - 1L))
    }
    out
}

sim_chunk_file <- function (dir, ch) 
file.path(dir, sprintf("chunk_%04d_%05d_%05d.rds", ch$cond, ch$from, ch$to))

sim_condition <- function (spec, ci) 
{
    g <- spec$grid[spec$grid$index == ci, ]
    list(index = ci, N = g$N, ratio = spec$ratios[[g$ratio]], scenario = g$scenario)
}

sim_pa_ref_for <- function (spec, cond) 
{
    pa <- spec$analyses$pa
    if (!isTRUE(pa$enabled) || !isTRUE(pa$per_cell)) 
        return(NULL)
    RNGkind("Mersenne-Twister", "Inversion", "Rejection")
    set.seed(sim_seed(spec$seed, cond$index, 0L))
    sim_pa_reference(cond$N, length(spec$pop$items), pa$n_iter, pa$quant)
}

sim_run_chunk <- function (dir, ch) 
{
    spec <- readRDS(file.path(dir, "spec.rds"))
    old <- options(mc.cores = 1L)
    on.exit(options(old), add = TRUE)
    cond <- sim_condition(spec, ch$cond)
    t0 <- Sys.time()
    ref <- sim_pa_ref_for(spec, cond)
    reps <- lapply(ch$from:ch$to, function(r) sim_replicate(spec$pop, cond, r, spec$seed, spec$estimators, 
        spec$analyses, spec$criteria, ref))
    f <- sim_chunk_file(dir, ch)
    tmp <- paste0(f, ".tmp")
    saveRDS(reps, tmp)
    file.rename(tmp, f)
    list(file = basename(f), seconds = as.numeric(difftime(Sys.time(), t0, units = "secs")), reps = length(reps))
}

sim_pop_ordinal_moments <- function (pop) 
{
    p <- length(pop$items)
    R <- pop$Lambda %*% pop$Psi %*% t(pop$Lambda)
    diag(R) <- 1
    mu <- vapply(pop$items, function(it) sum(seq_along(pop$props[[it]]) * pop$props[[it]]), numeric(1))
    S <- matrix(0, p, p, dimnames = list(pop$items, pop$items))
    for (i in seq_len(p)) {
        pr <- pop$props[[i]]
        k <- seq_along(pr)
        S[i, i] <- sum(k^2 * pr) - mu[i]^2
    }
    cdf <- function(a, b, r) {
        a <- pmin(pmax(a, -38), 38)
        b <- pmin(pmax(b, -38), 38)
        pbivnorm::pbivnorm(a, b, r)
    }
    for (i in seq_len(p - 1L)) for (j in (i + 1L):p) {
        ti <- c(-Inf, pop$tau[[i]], Inf)
        tj <- c(-Inf, pop$tau[[j]], Inf)
        Ki <- length(ti) - 1L
        Kj <- length(tj) - 1L
        g <- expand.grid(a = seq_len(Ki), b = seq_len(Kj))
        pr <- cdf(ti[g$a + 1L], tj[g$b + 1L], R[i, j]) - cdf(ti[g$a], tj[g$b + 1L], R[i, j]) - cdf(ti[g$a + 
            1L], tj[g$b], R[i, j]) + cdf(ti[g$a], tj[g$b], R[i, j])
        S[i, j] <- S[j, i] <- sum(g$a * g$b * pr) - mu[i] * mu[j]
    }
    S
}

sim_alpha_pop <- function (S, items) 
{
    k <- length(items)
    s <- S[items, items]
    k/(k - 1) * (1 - sum(diag(s))/sum(s))
}

sim_true_values <- function (pop, estimators) 
{
    lam <- pop$Lambda
    Psi <- pop$Psi
    gen <- data.frame(name = character(), type = character(), true = numeric(), stringsAsFactors = FALSE)
    for (f in pop$fnames) for (it in pop$factors[[f]]) gen[nrow(gen) + 1L, ] <- list(paste0(f, "=~", 
        it), "loading", lam[it, f])
    fn <- pop$fnames
    for (j in seq_along(fn)) for (i in seq_len(j - 1L)) gen[nrow(gen) + 1L, ] <- list(paste0(fn[i], "~~", 
        fn[j]), "factor_cor", Psi[fn[i], fn[j]])
    S_obs <- if (pop$data_type == "continuous") {
        S <- lam %*% Psi %*% t(lam)
        diag(S) <- 1
        S
    }
    else sim_pop_ordinal_moments(pop)
    out <- list()
    for (est in estimators) {
        tv <- gen
        rel <- data.frame(factor = fn, alpha = vapply(fn, function(f) sim_alpha_pop(S_obs, pop$factors[[f]]), 
            numeric(1)), omega = NA_real_, stringsAsFactors = FALSE)
        if (pop$data_type == "ordinal" && est == "WLSMV") {
            for (it in pop$items) for (t in seq_along(pop$tau[[it]])) tv[nrow(tv) + 1L, ] <- list(paste0(it, 
                "|t", t), "threshold", pop$tau[[it]][t])
        }
        if (est != "WLSMV") {
            fit <- suppressWarnings(lavaan::cfa(sim_model_syntax(pop), sample.cov = S_obs, sample.nobs = 1000000L, 
                std.lv = TRUE))
            if (pop$data_type == "ordinal") {
                ss <- lavaan::standardizedSolution(fit)
                key <- ifelse(ss$op == "=~", paste0(ss$lhs, "=~", ss$rhs), paste0(ss$lhs, "~~", ss$rhs))
                tv$true[tv$type %in% c("loading", "factor_cor")] <- ss$est.std[match(tv$name[tv$type %in% 
                  c("loading", "factor_cor")], key)]
                tv$source <- "pseudo_true"
            }
            om <- suppressWarnings(semTools::compRelSEM(fit, obs.var = TRUE, simplify = TRUE))
            rel$omega <- if (length(fn) == 1L) 
                as.numeric(unclass(om))
            else as.numeric(om[fn])
        }
        if (is.null(tv$source)) 
            tv$source <- "generating"
        lm <- list()
        if (length(pop$groups) >= 2L && (pop$data_type == "continuous" || est == "WLSMV")) {
            for (g in pop$groups[-1]) for (f in fn) lm[[length(lm) + 1L]] <- data.frame(name = paste0(f, 
                "~1@", g$name), type = "latent_mean", true = g$alpha[[f]], source = "generating")
        }
        out[[est]] <- list(params = tv, reliability = rel, latent_means = if (length(lm)) do.call(rbind, 
            lm) else NULL)
    }
    out
}

spec <- readRDS(file.path("sonuclar", "spec.rds"))
gercek <- sim_true_values(spec$pop, spec$estimators)
saveRDS(gercek, file.path("sonuclar", "gercek_degerler.rds"))
for (e in names(gercek)) utils::write.csv(gercek[[e]]$params, file.path("sonuclar", paste0("gercek_degerler_", e, ".csv")), row.names = FALSE)

