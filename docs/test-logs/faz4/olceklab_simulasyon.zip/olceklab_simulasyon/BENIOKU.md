# ÖlçekLab simülasyon paketi

SİMÜLASYON — sentetik veri; ölçeğin geçerliğine kanıt değildir.

Bu paket ÖlçekLab'de tanımlanan simülasyonu kendi bilgisayarınızda ya da bir hesaplama düğümünde baştan üretir.

## Çalıştırma

```
CEKIRDEK=4 sh 04_calistir.sh
```

- `02_simulasyon.R`: tekrarları üretip analiz eder; her parça `sonuclar/` altına `.rds` olarak yazılır. İş kesilirse yeniden çalıştırın; eksik parçalardan devam eder.
- `03_gercek_degerler.R`: gerçek değerleri (üretim parametreleri ya da kesin popülasyon momentlerinden sözde-gerçek değerler) hesaplar.
- `05_ozet.R`: yanlılık, kapsama, güç ve I. tip hata özetlerini `sonuclar/` altına yazar.

## Tekrarlanabilirlik

- RNG: `RNGkind("Mersenne-Twister", "Inversion", "Rejection")`; tekrar tohumu `seed + 10000 · koşul + tekrar`.
- Koşul indeksleri, tohumlar ve kestirilen nicelik tablosu `params.json` dosyasındadır.
- Paket, ÖlçekLab'in kullandığı R fonksiyonlarının birebir kopyasını içerir; aynı paket sürümleriyle aynı sonuçları verir. Sürüm farkı varsa betikler uyarı verir.
- Çok çekirdekte çalıştırmak sonuçları değiştirmez: her tekrarın tohumu kendine aittir.

