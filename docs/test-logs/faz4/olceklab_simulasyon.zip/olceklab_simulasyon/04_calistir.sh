#!/bin/sh
# ÖlçekLab bağımsız simülasyon paketi. Kullanım: CEKIRDEK=4 sh 04_calistir.sh
set -e
export LANG=C.UTF-8 LC_ALL=C.UTF-8
Rscript 02_simulasyon.R
Rscript 03_gercek_degerler.R
Rscript 05_ozet.R

